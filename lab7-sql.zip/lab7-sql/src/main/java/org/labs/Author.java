package org.labs;

import java.util.ArrayList;
import java.util.List;

class Author {
    private int id;
    private String name;

    private List<Book> books;

    public Author(int id, String name) {
        this.id = id;
        this.name = name;
        books = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Book> getBooks() {
        return books;
    }
}
