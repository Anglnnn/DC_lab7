package org.labs;

import java.sql.*;
import java.util.Scanner;

public class LibraryManager {

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/library_db";
    static final String USER = "root";
    static final String PASS = "12345";



    private static void addAuthor(Statement stmt, String authorName) throws SQLException {
        String sql = "INSERT INTO authors (name) VALUES ('" + authorName + "')";
        stmt.executeUpdate(sql);
        System.out.println("Додано нового автора: " + authorName);
    }

    private static void addBook(Statement stmt, String title, String isbn, int authorID) throws SQLException {
        String sql = "INSERT INTO books (title, isbn, author_id) VALUES ('" + title + "', '" + isbn + "', " + authorID + ")";
        stmt.executeUpdate(sql);
        System.out.println("Додано нову книгу: " + title);
    }

    private static int getAuthorID(Statement stmt, String authorName) throws SQLException {
        String sql = "SELECT id FROM authors WHERE name = '" + authorName + "'";
        ResultSet rs = stmt.executeQuery(sql);

        if (rs.next()) {
            return rs.getInt("id");
        }

        return -1;
    }

    private static void displayBooksByAuthor(Statement stmt, String authorName) throws SQLException {
        int authorID = getAuthorID(stmt, authorName);
        if (authorID != -1) {
            String sql = "SELECT * FROM books WHERE author_id = " + authorID;
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Книги автора " + authorName + ":");
            while (rs.next()) {
                System.out.println("Назва: " + rs.getString("title") + ", ISBN: " + rs.getString("isbn"));
            }
        } else {
            System.out.println("Автор " + authorName + " не знайдений.");
        }
    }

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        Scanner scanner = new Scanner(System.in);

        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();

            int choice;

            do {
                System.out.println("Library Manager Menu:");
                System.out.println("1. Print all books");
                System.out.println("2. Print all authors");
                System.out.println("3. Add new author");
                System.out.println("4. Remove author");
                System.out.println("5. Update author");
                System.out.println("6. Find author by name");
                System.out.println("7. Add book to author");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");

                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        printAllBooks(stmt);
                        break;
                    case 2:
                        printAllAuthors(stmt);
                        break;
                    case 3:
                        addNewAuthor(stmt);
                        break;
                    case 4:
                        removeAuthor(stmt);
                        break;
                    case 5:
                        updateAuthor(stmt);
                        break;
                    case 6:
                        findAuthorByName(stmt);
                        break;
                    case 7:
                        addBookToAuthor(stmt);
                        break;
                    case 0:
                        System.out.println("Exiting Library Manager.");
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } while (choice != 0);

        } catch (SQLException | ClassNotFoundException se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
                if (scanner != null) scanner.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }

    public static void printAllBooks(Statement stmt) throws SQLException {
        String sql = "SELECT books.*, authors.name AS author_name " +
                "FROM books JOIN authors ON books.author_id = authors.id";
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            int bookId = rs.getInt("id");
            String title = rs.getString("title");
            String isbn = rs.getString("isbn");
            String authorName = rs.getString("author_name");

            System.out.println("Book ID: " + bookId + ", Title: " + title +
                    ", ISBN: " + isbn + ", Author: " + authorName);
        }
    }

    public static void printAllAuthors(Statement stmt) throws SQLException {
        String sql = "SELECT * FROM authors";
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            int authorId = rs.getInt("id");
            String authorName = rs.getString("name");

            System.out.println("Author ID: " + authorId + ", Name: " + authorName);
        }
    }

    public static void addNewAuthor(Statement stmt) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author name: ");
        String authorName = scanner.nextLine();

        String sql = "INSERT INTO authors (name) VALUES ('" + authorName + "')";
        stmt.executeUpdate(sql);
        System.out.println("New author added: " + authorName);
    }

    public static void removeAuthor(Statement stmt) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author ID to remove: ");
        int authorId = scanner.nextInt();

        String sql = "DELETE FROM authors WHERE id = " + authorId;
        int affectedRows = stmt.executeUpdate(sql);

        if (affectedRows > 0) {
            System.out.println("Author removed successfully.");
        } else {
            System.out.println("No author found with ID: " + authorId);
        }
    }

    public static void updateAuthor(Statement stmt) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author ID to update: ");
        int authorId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new author name: ");
        String newAuthorName = scanner.nextLine();

        String sql = "UPDATE authors SET name = '" + newAuthorName + "' WHERE id = " + authorId;
        int affectedRows = stmt.executeUpdate(sql);

        if (affectedRows > 0) {
            System.out.println("Author updated successfully.");
        } else {
            System.out.println("No author found with ID: " + authorId);
        }
    }

    public static void findAuthorByName(Statement stmt) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author name to find: ");
        String authorName = scanner.nextLine();

        String sql = "SELECT * FROM authors WHERE name = '" + authorName + "'";
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            int authorId = rs.getInt("id");
            String foundAuthorName = rs.getString("name");

            System.out.println("Author found - ID: " + authorId + ", Name: " + foundAuthorName);
        }
    }

    public static void addBookToAuthor(Statement stmt) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author ID to add a book: ");
        int authorId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter book title: ");
        String bookTitle = scanner.nextLine();

        System.out.print("Enter book ISBN: ");
        String bookISBN = scanner.nextLine();

        String sql = "INSERT INTO books (title, isbn, author_id) VALUES ('" + bookTitle + "', '" + bookISBN + "', " + authorId + ")";
        stmt.executeUpdate(sql);
        System.out.println("New book added to the author.");
    }

}
