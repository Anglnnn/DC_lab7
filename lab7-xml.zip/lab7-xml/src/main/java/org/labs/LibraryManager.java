package org.labs;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import java.util.ArrayList;
import java.util.Scanner;

public class LibraryManager {
    private List<Author> authors;

    private void loadFromXML(String filename) {
        try {
            File file = new File(filename);
            if (!file.exists()) {
                authors = new ArrayList<>();
                return;
            }

            JAXBContext context = JAXBContext.newInstance(Library.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            Library library = (Library) unmarshaller.unmarshal(file);
            authors = library.getAuthors();
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    private void saveToXML(String filename) {
        try {
            JAXBContext context = JAXBContext.newInstance(Library.class);
            Marshaller marshaller = context.createMarshaller();
            Library library = new Library(authors);
            marshaller.marshal(library, new File(filename));
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    public void addAuthor(Author author) {
        if (authors == null) {
            authors = new ArrayList<>();
        }
        authors.add(author);
    }

    public void removeAuthor(Author author) {
        if (authors != null) {
            authors.remove(author);
        }
    }

    public void updateAuthor(Author updatedAuthor) {
        if (authors != null) {
            for (int i = 0; i < authors.size(); i++) {
                Author existingAuthor = authors.get(i);
                if (existingAuthor.getName().equals(updatedAuthor.getName())) {
                    authors.set(i, updatedAuthor);
                    break;
                }
            }
        }
    }

    public Author findAuthorByName(String name) {
        if (authors != null) {
            for (Author author : authors) {
                if (author.getName().equals(name)) {
                    return author;
                }
            }
        }
        return null;
    }

    public List<Author> getAllAuthors() {
        return authors;
    }

    private void printAllBooks() {
        if (authors != null) {
            for (Author author : authors) {
                for (Book book : author.getBooks()) {
                    System.out.println("Title: " + book.getTitle() + ", ISBN: " + book.getIsbn());
                }
            }
        } else {
            System.out.println("No authors in the library.");
        }
    }

    private void printAllAuthors() {
        if (authors != null) {
            for (Author author : authors) {
                System.out.println("Author: " + author.getName());
            }
        } else {
            System.out.println("No authors in the library.");
        }
    }

    private void addNewAuthor() {
        Scanner scanner = new Scanner(System.in);
        Author newAuthor = new Author();

        System.out.print("Enter author name: ");
        newAuthor.setName(scanner.nextLine());


        if (authors == null) {
            authors = new ArrayList<>();
        }

        authors.add(newAuthor);
        System.out.println("Author added successfully.");
    }

    private void removeAuthor() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author name to remove: ");
        String authorNameToRemove = scanner.nextLine();

        if (authors != null) {
            authors.removeIf(author -> author.getName().equals(authorNameToRemove));
            System.out.println("Author removed successfully.");
        } else {
            System.out.println("No authors in the library.");
        }
    }

    private void updateAuthor() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author name to update: ");
        String authorNameToUpdate = scanner.nextLine();

        if (authors != null) {
            for (Author existingAuthor : authors) {
                if (existingAuthor.getName().equals(authorNameToUpdate)) {
                    System.out.print("Enter new name for the author: ");
                    String newAuthorName = scanner.nextLine();
                    existingAuthor.setName(newAuthorName);
                    System.out.println("Author updated successfully.");
                    return;
                }
            }
            System.out.println("Author not found.");
        } else {
            System.out.println("No authors in the library.");
        }
    }

    private void findAuthorByName() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author name to find: ");
        String authorNameToFind = scanner.nextLine();

        Author foundAuthor = findAuthorByName(authorNameToFind);

        if (foundAuthor != null) {
            System.out.println("Author found: " + foundAuthor.getName());
        } else {
            System.out.println("Author not found.");
        }
    }

    private void addBookToAuthor(Author author) {
        Scanner scanner = new Scanner(System.in);
        Book newBook = new Book();

        System.out.print("Enter book title: ");
        newBook.setTitle(scanner.nextLine());

        System.out.print("Enter book ISBN: ");
        newBook.setIsbn(scanner.nextLine());

        author.addBook(newBook);
        System.out.println("Book added to the author successfully.");
    }

    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager();
        manager.loadFromXML("library.xml");

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Library Manager Menu:");
            System.out.println("1. Print all books");
            System.out.println("2. Print all authors");
            System.out.println("3. Add new author");
            System.out.println("4. Remove author");
            System.out.println("5. Update author");
            System.out.println("6. Find author by name");
            System.out.println("7. Add book to author");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manager.printAllBooks();
                    break;
                case 2:
                    manager.printAllAuthors();
                    break;
                case 3:
                    manager.addNewAuthor();
                    break;
                case 4:
                    manager.removeAuthor();
                    break;
                case 5:
                    manager.updateAuthor();
                    break;
                case 6:
                    manager.findAuthorByName();
                    break;
                case 7:
                    System.out.print("Enter author name:");
                    Author author = manager.findAuthorByName(scanner.nextLine());
                    manager.addBookToAuthor(author);
                    break;
                case 0:
                    System.out.println("Exiting Library Manager.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);

        manager.saveToXML("library.xml");
    }
}


