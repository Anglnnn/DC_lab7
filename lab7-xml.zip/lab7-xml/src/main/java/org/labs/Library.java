package org.labs;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class Library {
    private List<Author> authors;

    public Library(List<Author> authors) {
        this.authors = authors;
    }

    @XmlElementWrapper(name = "authors")
    @XmlElement(name = "author")
    public List<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors;
    }

    public Library() {
    }
}
